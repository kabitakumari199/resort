import styled from 'styled-components';

const SimpleButton = styled.button `
 color:red;
 background-color:green;
` 

export default SimpleButton;
