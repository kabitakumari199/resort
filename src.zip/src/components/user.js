import React from 'react';

class User extends React.Component {
   render(){
     return(
       <div><h1>Here User list will come!</h1></div>
     )
   }
}
export default User;
